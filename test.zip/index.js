const express = require("express");
const bodyParser = require("body-parser")
const http = require("http");
const { runInNewContext } = require("vm");
const app = express();

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}))


app.get('/',(req,res)=>{
    console.log("got a request");
    console.log(req.query.a);
    res.send("hello, welcome to the website "+ req.query.a);
})
app.listen(3000);
